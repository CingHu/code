/*
 * passwd.h
 *
 *  Created on: 2013-2-28
 *      Author: changqian
 */

#ifndef PASSWD_H_
#define PASSWD_H_



#include "lib/utils.h"



bool configure_password(header_list_t *list);



#endif /* PASSWD_H_ */
