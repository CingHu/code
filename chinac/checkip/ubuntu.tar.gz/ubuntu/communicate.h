/*
 * communicate.h
 *
 *  Created on: 2013-3-8
 *      Author: changqian
 */

#ifndef COMMUNICATE_H_
#define COMMUNICATE_H_



#include "lib/utils.h"
#include "checkip.h"


header_list_t *retrieve_configuration(inetface_t *iface);



#endif /* COMMUNICATE_H_ */
