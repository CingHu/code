/*
 * response.h
 *
 *  Created on: 2013-3-1
 *      Author: changqian
 */

#ifndef RESPONSE_H_
#define RESPONSE_H_



#include "lib/utils.h"
#include "checkip.h"



header_list_t *handle_response(http_response_t *resp);



#endif /* RESPONSE_H_ */
